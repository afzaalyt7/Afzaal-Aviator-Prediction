const roundStatus = document.getElementById("roundStatus");
const roundInfo = document.getElementById("roundInfo");
const historyList = document.getElementById("historyList");
const notification = document.getElementById("notification");
const accuracyDisplay = document.getElementById("accuracy");
let timerInterval;
let totalRounds = 0;
let successfulPredictions = 0;

// Fetching data from API
function fetchRoundData() {
    fetch('/get_round_data')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error("Error:", data.error);
                return;
            }
            updateRound(data.roundStatus, data.roundInfo);
        })
        .catch(error => console.error("Fetch error:", error));
}

// Update Round Status
function updateRound(status, info) {
    roundStatus.textContent = status;
    roundInfo.textContent = info;
    notification.textContent = "New round updated!";
    notification.style.display = "block";

    // Update history and accuracy
    totalRounds += 1;
    if (status === "Round Active!") {
        successfulPredictions += 1; // This is a dummy condition for illustration
    }
    const newHistory = document.createElement("li");
    newHistory.textContent = `Round completed with status: ${status} at ${new Date().toLocaleTimeString()}`;
    historyList.appendChild(newHistory);

    // Update accuracy
    updateAccuracy();
}

// Update accuracy display
function updateAccuracy() {
    const accuracy = totalRounds > 0 ? Math.round((successfulPredictions / totalRounds) * 100) : 0;
    accuracyDisplay.textContent = `${accuracy}%`;
}

// Start Timer for fetching data periodically
function startFetchingData() {
    fetchRoundData(); // Initial fetch
    setInterval(fetchRoundData, 5000); // Fetch data every 5 seconds
}

// Event Listeners for Buttons
document.getElementById("startPrediction").addEventListener("click", () => {
    roundStatus.textContent = "Round Active!";
    roundInfo.textContent = "Predicting...";
    notification.textContent = "Prediction started!";
    notification.style.display = "block";
    startFetchingData();
});

document.getElementById("stopPrediction").addEventListener("click", () => {
    clearInterval(timerInterval);
    roundInfo.textContent = "Prediction Stopped";
    roundStatus.textContent = "Round Inactive";
    notification.style.display = "none";
});
