from flask import Flask, jsonify
import requests
import logging
from datetime import datetime

app = Flask(__name__)

# Configure logging
logging.basicConfig(filename='app.log', level=logging.INFO)

API_ENDPOINT = "https://bet7k-aviator-api.p.rapidapi.com/bet7k-aviator-latest"
API_KEY = "aa95feeaabmsh9d554c50f51582dp122212jsn874613f90d1a"

@app.route('/get_round_data', methods=['GET'])
def get_round_data():
    try:
        headers = {
            "Authorization": f"Bearer {API_KEY}"
        }
        response = requests.get(API_ENDPOINT, headers=headers)
        response.raise_for_status()  # Raise an error for bad responses
        data = response.json()

        round_data = {
            "roundStatus": data.get("roundStatus", "waiting"),
            "roundInfo": data.get("roundInfo", "00:00x")
        }
        
        logging.info(f"{datetime.now()}: Fetched round data: {round_data}")
        return jsonify(round_data)
    except Exception as e:
        logging.error(f"Error fetching data: {e}")
        return jsonify({"error": "Failed to fetch data"}), 500

if __name__ == '__main__':
    app.run(debug=True)
